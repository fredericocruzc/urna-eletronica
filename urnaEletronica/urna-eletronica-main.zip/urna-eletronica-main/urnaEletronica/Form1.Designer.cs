﻿namespace urnaEletronica
{
    partial class Form1
    {
        /// <summary>
        /// Variável de designer necessária.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Limpar os recursos que estão sendo usados.
        /// </summary>
        /// <param name="disposing">true se for necessário descartar os recursos gerenciados; caso contrário, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Código gerado pelo Windows Form Designer

        /// <summary>
        /// Método necessário para suporte ao Designer - não modifique 
        /// o conteúdo deste método com o editor de código.
        /// </summary>
        private void InitializeComponent()
        {
            this.button1 = new System.Windows.Forms.Button();
            this.button2 = new System.Windows.Forms.Button();
            this.button3 = new System.Windows.Forms.Button();
            this.button4 = new System.Windows.Forms.Button();
            this.button5 = new System.Windows.Forms.Button();
            this.button6 = new System.Windows.Forms.Button();
            this.button7 = new System.Windows.Forms.Button();
            this.button8 = new System.Windows.Forms.Button();
            this.button9 = new System.Windows.Forms.Button();
            this.button10 = new System.Windows.Forms.Button();
            this.panel1 = new System.Windows.Forms.Panel();
            this.textN2 = new System.Windows.Forms.TextBox();
            this.textN1 = new System.Windows.Forms.TextBox();
            this.lbPartido = new System.Windows.Forms.Label();
            this.lbNome = new System.Windows.Forms.Label();
            this.lbNumero = new System.Windows.Forms.Label();
            this.lbSeu = new System.Windows.Forms.Label();
            this.lbPrefeito = new System.Windows.Forms.Label();
            this.buttonBranco = new System.Windows.Forms.Button();
            this.buttonCorrige = new System.Windows.Forms.Button();
            this.buttonConfirma = new System.Windows.Forms.Button();
            this.panel1.SuspendLayout();
            this.SuspendLayout();
            // 
            // button1
            // 
            this.button1.BackColor = System.Drawing.Color.DimGray;
            this.button1.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.button1.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button1.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.button1.Location = new System.Drawing.Point(594, 110);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(50, 45);
            this.button1.TabIndex = 0;
            this.button1.Text = "1";
            this.button1.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.button1.UseVisualStyleBackColor = false;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // button2
            // 
            this.button2.BackColor = System.Drawing.SystemColors.ControlDarkDark;
            this.button2.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.button2.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button2.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.button2.Location = new System.Drawing.Point(656, 110);
            this.button2.Name = "button2";
            this.button2.Size = new System.Drawing.Size(50, 45);
            this.button2.TabIndex = 1;
            this.button2.Text = "2";
            this.button2.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.button2.UseVisualStyleBackColor = false;
            this.button2.Click += new System.EventHandler(this.button2_Click);
            // 
            // button3
            // 
            this.button3.BackColor = System.Drawing.SystemColors.ControlDarkDark;
            this.button3.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.button3.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button3.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.button3.Location = new System.Drawing.Point(719, 110);
            this.button3.Name = "button3";
            this.button3.Size = new System.Drawing.Size(50, 45);
            this.button3.TabIndex = 2;
            this.button3.Text = "3";
            this.button3.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.button3.UseVisualStyleBackColor = false;
            this.button3.Click += new System.EventHandler(this.button3_Click);
            // 
            // button4
            // 
            this.button4.BackColor = System.Drawing.SystemColors.ControlDarkDark;
            this.button4.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.button4.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button4.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.button4.Location = new System.Drawing.Point(594, 164);
            this.button4.Name = "button4";
            this.button4.Size = new System.Drawing.Size(50, 45);
            this.button4.TabIndex = 3;
            this.button4.Text = "4";
            this.button4.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.button4.UseVisualStyleBackColor = false;
            this.button4.Click += new System.EventHandler(this.button4_Click);
            // 
            // button5
            // 
            this.button5.BackColor = System.Drawing.SystemColors.ControlDarkDark;
            this.button5.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.button5.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button5.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.button5.Location = new System.Drawing.Point(656, 164);
            this.button5.Name = "button5";
            this.button5.Size = new System.Drawing.Size(50, 45);
            this.button5.TabIndex = 4;
            this.button5.Text = "5";
            this.button5.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.button5.UseVisualStyleBackColor = false;
            this.button5.Click += new System.EventHandler(this.button5_Click);
            // 
            // button6
            // 
            this.button6.BackColor = System.Drawing.SystemColors.ControlDarkDark;
            this.button6.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.button6.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button6.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.button6.Location = new System.Drawing.Point(719, 164);
            this.button6.Name = "button6";
            this.button6.Size = new System.Drawing.Size(50, 45);
            this.button6.TabIndex = 5;
            this.button6.Text = "6";
            this.button6.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.button6.UseVisualStyleBackColor = false;
            this.button6.Click += new System.EventHandler(this.button6_Click);
            // 
            // button7
            // 
            this.button7.BackColor = System.Drawing.SystemColors.ControlDarkDark;
            this.button7.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.button7.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button7.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.button7.Location = new System.Drawing.Point(594, 219);
            this.button7.Name = "button7";
            this.button7.Size = new System.Drawing.Size(50, 45);
            this.button7.TabIndex = 6;
            this.button7.Text = "7";
            this.button7.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.button7.UseVisualStyleBackColor = false;
            this.button7.Click += new System.EventHandler(this.button7_Click);
            // 
            // button8
            // 
            this.button8.BackColor = System.Drawing.SystemColors.ControlDarkDark;
            this.button8.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.button8.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button8.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.button8.Location = new System.Drawing.Point(656, 219);
            this.button8.Name = "button8";
            this.button8.Size = new System.Drawing.Size(50, 45);
            this.button8.TabIndex = 7;
            this.button8.Text = "8";
            this.button8.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.button8.UseVisualStyleBackColor = false;
            this.button8.Click += new System.EventHandler(this.button8_Click);
            // 
            // button9
            // 
            this.button9.BackColor = System.Drawing.SystemColors.ControlDarkDark;
            this.button9.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.button9.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button9.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.button9.Location = new System.Drawing.Point(719, 219);
            this.button9.Name = "button9";
            this.button9.Size = new System.Drawing.Size(50, 45);
            this.button9.TabIndex = 8;
            this.button9.Text = "9";
            this.button9.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.button9.UseVisualStyleBackColor = false;
            this.button9.Click += new System.EventHandler(this.button9_Click);
            // 
            // button10
            // 
            this.button10.BackColor = System.Drawing.SystemColors.ControlDarkDark;
            this.button10.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.button10.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button10.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.button10.Location = new System.Drawing.Point(656, 273);
            this.button10.Name = "button10";
            this.button10.Size = new System.Drawing.Size(50, 45);
            this.button10.TabIndex = 9;
            this.button10.Text = "0";
            this.button10.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.button10.UseVisualStyleBackColor = false;
            this.button10.Click += new System.EventHandler(this.button10_Click);
            // 
            // panel1
            // 
            this.panel1.BackColor = System.Drawing.SystemColors.HighlightText;
            this.panel1.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panel1.Controls.Add(this.textN2);
            this.panel1.Controls.Add(this.textN1);
            this.panel1.Controls.Add(this.lbPartido);
            this.panel1.Controls.Add(this.lbNome);
            this.panel1.Controls.Add(this.lbNumero);
            this.panel1.Controls.Add(this.lbSeu);
            this.panel1.Controls.Add(this.lbPrefeito);
            this.panel1.Location = new System.Drawing.Point(27, 54);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(514, 337);
            this.panel1.TabIndex = 13;
            this.panel1.Paint += new System.Windows.Forms.PaintEventHandler(this.panel1_Paint);
            // 
            // textN2
            // 
            this.textN2.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.textN2.Location = new System.Drawing.Point(116, 98);
            this.textN2.Multiline = true;
            this.textN2.Name = "textN2";
            this.textN2.Size = new System.Drawing.Size(35, 41);
            this.textN2.TabIndex = 6;
            this.textN2.TextChanged += new System.EventHandler(this.textN2_TextChanged);
            // 
            // textN1
            // 
            this.textN1.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.textN1.Location = new System.Drawing.Point(75, 98);
            this.textN1.Multiline = true;
            this.textN1.Name = "textN1";
            this.textN1.Size = new System.Drawing.Size(35, 41);
            this.textN1.TabIndex = 5;
            this.textN1.TextChanged += new System.EventHandler(this.textN1_TextChanged);
            // 
            // lbPartido
            // 
            this.lbPartido.AutoSize = true;
            this.lbPartido.Font = new System.Drawing.Font("Microsoft Tai Le", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbPartido.Location = new System.Drawing.Point(16, 182);
            this.lbPartido.Name = "lbPartido";
            this.lbPartido.Size = new System.Drawing.Size(48, 14);
            this.lbPartido.TabIndex = 4;
            this.lbPartido.Text = "Partido:";
            // 
            // lbNome
            // 
            this.lbNome.AutoSize = true;
            this.lbNome.Font = new System.Drawing.Font("Microsoft Tai Le", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbNome.Location = new System.Drawing.Point(16, 151);
            this.lbNome.Name = "lbNome";
            this.lbNome.Size = new System.Drawing.Size(42, 14);
            this.lbNome.TabIndex = 3;
            this.lbNome.Text = "Nome:";
            // 
            // lbNumero
            // 
            this.lbNumero.AutoSize = true;
            this.lbNumero.Font = new System.Drawing.Font("Microsoft Tai Le", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbNumero.Location = new System.Drawing.Point(16, 126);
            this.lbNumero.Name = "lbNumero";
            this.lbNumero.Size = new System.Drawing.Size(53, 14);
            this.lbNumero.TabIndex = 2;
            this.lbNumero.Text = "Número:";
            // 
            // lbSeu
            // 
            this.lbSeu.AutoSize = true;
            this.lbSeu.Font = new System.Drawing.Font("Microsoft YaHei", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbSeu.Location = new System.Drawing.Point(16, 17);
            this.lbSeu.Name = "lbSeu";
            this.lbSeu.Size = new System.Drawing.Size(94, 16);
            this.lbSeu.TabIndex = 1;
            this.lbSeu.Text = "SEU VOTO PARA";
            // 
            // lbPrefeito
            // 
            this.lbPrefeito.AutoSize = true;
            this.lbPrefeito.Font = new System.Drawing.Font("Microsoft YaHei", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbPrefeito.Location = new System.Drawing.Point(76, 33);
            this.lbPrefeito.Name = "lbPrefeito";
            this.lbPrefeito.Size = new System.Drawing.Size(125, 31);
            this.lbPrefeito.TabIndex = 0;
            this.lbPrefeito.Text = "PREFEITO";
            this.lbPrefeito.Click += new System.EventHandler(this.label1_Click);
            // 
            // buttonBranco
            // 
            this.buttonBranco.BackColor = System.Drawing.SystemColors.ButtonHighlight;
            this.buttonBranco.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.buttonBranco.Location = new System.Drawing.Point(566, 344);
            this.buttonBranco.Name = "buttonBranco";
            this.buttonBranco.Size = new System.Drawing.Size(67, 40);
            this.buttonBranco.TabIndex = 7;
            this.buttonBranco.Text = "BRANCO";
            this.buttonBranco.TextAlign = System.Drawing.ContentAlignment.TopCenter;
            this.buttonBranco.UseVisualStyleBackColor = false;
            this.buttonBranco.Click += new System.EventHandler(this.buttonBranco_Click);
            // 
            // buttonCorrige
            // 
            this.buttonCorrige.BackColor = System.Drawing.Color.Red;
            this.buttonCorrige.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.buttonCorrige.Location = new System.Drawing.Point(648, 344);
            this.buttonCorrige.Name = "buttonCorrige";
            this.buttonCorrige.Size = new System.Drawing.Size(67, 40);
            this.buttonCorrige.TabIndex = 14;
            this.buttonCorrige.Text = "CORRIGE";
            this.buttonCorrige.TextAlign = System.Drawing.ContentAlignment.TopCenter;
            this.buttonCorrige.UseVisualStyleBackColor = false;
            this.buttonCorrige.Click += new System.EventHandler(this.buttonCorrige_Click);
            // 
            // buttonConfirma
            // 
            this.buttonConfirma.BackColor = System.Drawing.Color.Green;
            this.buttonConfirma.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.buttonConfirma.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.buttonConfirma.ForeColor = System.Drawing.SystemColors.ControlText;
            this.buttonConfirma.Location = new System.Drawing.Point(730, 320);
            this.buttonConfirma.Name = "buttonConfirma";
            this.buttonConfirma.Size = new System.Drawing.Size(73, 64);
            this.buttonConfirma.TabIndex = 15;
            this.buttonConfirma.Text = "CONFIRMA";
            this.buttonConfirma.UseVisualStyleBackColor = false;
            this.buttonConfirma.Click += new System.EventHandler(this.buttonConfirma_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.ControlDark;
            this.BackgroundImage = global::urnaEletronica.Properties.Resources.urna1;
            this.ClientSize = new System.Drawing.Size(825, 450);
            this.Controls.Add(this.buttonConfirma);
            this.Controls.Add(this.buttonCorrige);
            this.Controls.Add(this.buttonBranco);
            this.Controls.Add(this.panel1);
            this.Controls.Add(this.button10);
            this.Controls.Add(this.button9);
            this.Controls.Add(this.button8);
            this.Controls.Add(this.button7);
            this.Controls.Add(this.button6);
            this.Controls.Add(this.button5);
            this.Controls.Add(this.button4);
            this.Controls.Add(this.button3);
            this.Controls.Add(this.button2);
            this.Controls.Add(this.button1);
            this.Name = "Form1";
            this.Text = "Form1";
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.Button button2;
        private System.Windows.Forms.Button button3;
        private System.Windows.Forms.Button button4;
        private System.Windows.Forms.Button button5;
        private System.Windows.Forms.Button button6;
        private System.Windows.Forms.Button button7;
        private System.Windows.Forms.Button button8;
        private System.Windows.Forms.Button button9;
        private System.Windows.Forms.Button button10;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Label lbPrefeito;
        private System.Windows.Forms.Label lbSeu;
        private System.Windows.Forms.Label lbPartido;
        private System.Windows.Forms.Label lbNome;
        private System.Windows.Forms.Label lbNumero;
        private System.Windows.Forms.TextBox textN1;
        private System.Windows.Forms.TextBox textN2;
        private System.Windows.Forms.Button buttonBranco;
        private System.Windows.Forms.Button buttonCorrige;
        private System.Windows.Forms.Button buttonConfirma;
    }
}

